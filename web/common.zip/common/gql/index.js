/** @format */

import * as query from './query'
import * as mutation from './mutation'
import * as subscription from './subscription'

export {query, mutation, subscription}

