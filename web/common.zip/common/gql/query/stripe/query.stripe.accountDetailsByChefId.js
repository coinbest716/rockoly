export const accountDetailsByChefIdGQLTAG = `query stripeGetChefAccounts($chefId: String!) {
    stripeGetChefAccounts(chefId: $chefId) {
      data
    }
  }`


  /*{
  "chefId": ""
}
 */