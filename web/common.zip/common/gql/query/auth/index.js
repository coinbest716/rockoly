import {adminAuthenticateGQLTAG} from './query.auth.adminAuthenticate';
import {checkEmailAndMobileNoExistsGQLTAG} from './query.auth.checkEmailAndMobileNoExists';
import {checkEmailAndMobileNoExistsUsingUserIdGQLTAG} from './query.auth.checkEmailAndMobileNoExistsUsingUserId';

export {adminAuthenticateGQLTAG,checkEmailAndMobileNoExistsGQLTAG,checkEmailAndMobileNoExistsUsingUserIdGQLTAG};