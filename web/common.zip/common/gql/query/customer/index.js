import {listWithFiltersGQLTAG} from './query.customer.listWithFilters'
import {profileByIdGQLTAG} from './query.customer.profileById';

export {listWithFiltersGQLTAG,profileByIdGQLTAG};