import {getSettingValueGQLTAG} from './query.setting.getSettingValue';

export {getSettingValueGQLTAG};