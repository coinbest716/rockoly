import {totalCountGQLTAG} from './query.custom.totalCount';

export {totalCountGQLTAG};