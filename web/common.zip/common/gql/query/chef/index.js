import {profileByIdGQLTAG} from './query.chef.profileById';
import {listWithFiltersGQLTAG} from './query.chef.listWithFilters';
import {filterByParamsGQLTAG} from './query.chef.filterByParams';
import {listAllDetailsGQLTAG} from './query.chef.listAllDetails';

export {listWithFiltersGQLTAG,profileByIdGQLTAG,filterByParamsGQLTAG,listAllDetailsGQLTAG};