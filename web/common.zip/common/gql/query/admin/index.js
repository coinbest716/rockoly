import {profileByIdGQLTAG} from './query.admin.profileById';
import {searchGQLTAG} from './query.admin.search';
import {checkUserAdminGQLTAG} from './query.admin.checkUserAdmin';

export {profileByIdGQLTAG,searchGQLTAG,checkUserAdminGQLTAG};