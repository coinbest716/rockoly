import {filterByCustomerIdGQLTAG} from './query.follow.filterByCustomerId';

export {filterByCustomerIdGQLTAG};