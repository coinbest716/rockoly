import {conversationMessagesGQLTAG} from './query.chat.conversationMessages';
import {getConversationListGQLTAG} from './query.chat.getConversationList'

export {conversationMessagesGQLTAG,getConversationListGQLTAG};