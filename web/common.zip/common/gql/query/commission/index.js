import {filterMgmtByAdminIdGQLTAG} from './query.commission.filterMgmtByAdminId';
import {filterEarnedHistByAdminIdGQLTAG} from './query.commission.filterEarnedHistByAdminId';

export {filterMgmtByAdminIdGQLTAG,filterEarnedHistByAdminIdGQLTAG};