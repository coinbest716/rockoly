import { paymentByCustomerIdGQLTAG } from './query.payment.byCustomerId';
import { paymentByChefIdGQLTAG } from './query.payment.byChefId';

export { paymentByCustomerIdGQLTAG, paymentByChefIdGQLTAG };
