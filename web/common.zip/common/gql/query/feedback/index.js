import {byIdGQLTAG} from './query.feedback.byId'
import {listWithFiltersGQLTAG} from './query.feedback.listWithFilters'

export{byIdGQLTAG,listWithFiltersGQLTAG}