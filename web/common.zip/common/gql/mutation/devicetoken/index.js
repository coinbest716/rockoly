
import {addUserDeviceTokenGQLTAG} from './mutation.devicetoken.addUserDeviceToken'
import {removeUserDeviceTokenGQLTAG} from './mutation.devicetoken.removeUserDeviceToken'

export {addUserDeviceTokenGQLTAG,removeUserDeviceTokenGQLTAG};