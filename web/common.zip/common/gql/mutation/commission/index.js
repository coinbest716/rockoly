import {createMgmtHistGQLTAG} from './mutation.commission.createMgmtHist';

export {createMgmtHistGQLTAG};