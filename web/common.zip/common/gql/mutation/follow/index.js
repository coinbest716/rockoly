import {chefFollowOrUnFollowGQLTAG} from './mutation.follow.chefFollowOrUnFollow';

export {chefFollowOrUnFollowGQLTAG};