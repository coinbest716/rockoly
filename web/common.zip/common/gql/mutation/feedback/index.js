import {createGQLTAG} from './mutation.feedback.create';

export {createGQLTAG}