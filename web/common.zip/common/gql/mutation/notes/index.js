import {createNotesGQLTAG} from './mutation.notes.createNotes';

export {createNotesGQLTAG};