import {updateBasicInfoGQLTag} from './mutation.admin.updateBasicInfo';
import {transferAmountGQLTAG} from './mutation.admin.transferAmount'
import {refundAmountGQLTAG} from './mutation.admin.refundAmount'

export {updateBasicInfoGQLTag,transferAmountGQLTAG,refundAmountGQLTAG};
