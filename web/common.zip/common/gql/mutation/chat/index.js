import { createMsgGQLTAG } from './mutation.chat.createMsg';
import { createConversationGQLTAG } from './mutation.chat.createConversation';

export { createMsgGQLTAG, createConversationGQLTAG };
