import {sendEmailGQLTAG} from './mutation.custom.sendEmail';

export {sendEmailGQLTAG};
