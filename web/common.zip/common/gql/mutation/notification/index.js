import {updateStatusGQLTag} from './mutation.notification.updateStatus';

export {updateStatusGQLTag};