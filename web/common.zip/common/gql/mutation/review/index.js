import {createGQLTAG} from './mutation.review.create';
import {updateStatusByReviewIdGQLTAG} from './mutation.review.updateStatusByReviewId';

export {createGQLTAG,updateStatusByReviewIdGQLTAG};