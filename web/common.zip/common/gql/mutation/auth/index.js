import {ssoChefAuthtenticateGQLTAG} from './mutation.auth.ssoChefAuthtenticate';
import {ssoCustomerAuthtenticateGQLTAG} from './mutation.auth.ssoCustomerAuthtenticate';
import {authtenticateGQLTAG} from './mutation.auth.authenticate';
import {switchRoleGQLTAG} from './mutation.auth.switchRole'

export {authtenticateGQLTAG,ssoChefAuthtenticateGQLTAG,ssoCustomerAuthtenticateGQLTAG,switchRoleGQLTAG};