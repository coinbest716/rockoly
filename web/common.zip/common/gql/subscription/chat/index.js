import { messsageHistoryGQLTAG } from './query.subscription.chat.messageHistory';
import { conversationHistoryGQLTAG } from './query.subscription.chat.conversationHistory';

export { messsageHistoryGQLTAG, conversationHistoryGQLTAG };
