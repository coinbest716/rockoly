import {byChefIdGQLTAG} from './subscription.payment.byChefId';
import {byCustomerIdGQLTAG} from './subscription.payment.byCustomerId';

export {byChefIdGQLTAG,byCustomerIdGQLTAG}