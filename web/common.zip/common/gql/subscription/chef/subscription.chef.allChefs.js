export const allChefsGQLTAG=`subscription{
    chefProfile(chefStatusId: "APPROVED") {
      data
    }
  }`

  