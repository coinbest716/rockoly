import {followChefGQLTAG} from './subscription.customer.followChef';
import {profileGQLTAG} from './subscription.customer.profile';
import {profileExtendedGQLTAG} from './subscription.customer.profileExtended';
import {preferenceGQLTAG} from './subscription.customer.preference';

export {followChefGQLTAG,profileGQLTAG,profileExtendedGQLTAG,preferenceGQLTAG}