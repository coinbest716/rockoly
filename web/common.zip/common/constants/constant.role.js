/** @format */

export const ROLE = {
  CHEF: 'CHEF',
  CUSTOMER: 'CUSTOMER',
  ADMIN: 'ADMIN',
}
